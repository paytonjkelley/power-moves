/* =========================================================
   POWER MOVES — Contact & Partnerships page
   ---------------------------------------------------------
   WHERE SUBMISSIONS GO (FormSubmit — no account needed)
   GitHub Pages can't send email itself, so both forms post to
   FormSubmit (formsubmit.co), which emails each submission to
   the address below.

   1. Put the inbox for each form below (keep them separate:
      prayer requests should go to an inbox only your prayer
      team can read).
   2. Publish the site, then send one test from EACH form.
      FormSubmit emails that inbox an "Activate Form" link.
      Click it. Until you do, the form shows an error and
      nothing is delivered.
   3. After activating, FormSubmit gives you a random string.
      Paste it here in place of the email address so your
      address isn't visible in the site's code.

   Leave a value empty and that form won't pretend to send:
   it shows "not connected yet" and keeps what was typed.
   ========================================================= */
var CONTACT_INBOX = 'info@powermoveshub.com';   // → replace with FormSubmit's random string after activating
var PRAYER_INBOX  = 'info@powermoveshub.com';   // same inbox; prayer emails arrive with the subject "Power Moves — Prayer request"

var CONTACT_ENDPOINT = CONTACT_INBOX ? 'https://formsubmit.co/ajax/' + CONTACT_INBOX : '';
var PRAYER_ENDPOINT  = PRAYER_INBOX  ? 'https://formsubmit.co/ajax/' + PRAYER_INBOX  : '';

(function () {
  'use strict';

  var $ = function (sel, root) { return (root || document).querySelector(sel); };
  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  var REASONS = {
    'customer-support': 'Customer Support',
    'rental-payment': 'Rental & Payment',
    'host-a-station': 'Host a Station',
    'partner-support': 'Partner Support',
    'partnerships': 'Partnerships',
    'events-sponsors': 'Events & Sponsors',
    'general-inquiry': 'General Inquiry'
  };
  var params = new URLSearchParams(window.location.search);

  /* ---------- Helpers ---------- */
  function digits(v) { return (v || '').replace(/\D/g, ''); }
  function validPhone(v) { var d = digits(v); return d.length >= 10 && d.length <= 15; }

  function setError(input, msg) {
    var err = document.getElementById(input.id + '-error');
    if (msg) {
      input.setAttribute('aria-invalid', 'true');
      if (err) { err.querySelector('span').textContent = msg; err.hidden = false; }
    } else {
      input.removeAttribute('aria-invalid');
      if (err) { err.hidden = true; err.querySelector('span').textContent = ''; }
    }
  }
  function showAlert(el, msg) {
    if (!el) return;
    el.querySelector('span').textContent = msg;
    el.hidden = false;
  }
  function hideAlert(el) { if (el) el.hidden = true; }

  function setLoading(btn, on, idleLabel, busyLabel) {
    btn.disabled = on;
    btn.classList.toggle('is-loading', on);
    btn.setAttribute('aria-busy', on ? 'true' : 'false');
    btn.querySelector('.btn-label').textContent = on ? busyLabel : idleLabel;
  }

  /* Live character counter for a textarea with maxlength */
  function wireCounter(textarea) {
    var counter = document.getElementById(textarea.id + '-count');
    if (!counter) return;
    var out = counter.querySelector('[data-count]');
    var max = parseInt(textarea.getAttribute('maxlength'), 10);
    function update() {
      if (textarea.value.length > max) textarea.value = textarea.value.slice(0, max);
      var n = textarea.value.length;
      out.textContent = n.toLocaleString('en-US');
      counter.classList.toggle('is-near', n >= max * 0.9 && n < max);
      counter.classList.toggle('is-max', n >= max);
    }
    textarea.addEventListener('input', update);
    update();
  }

  /* Sends the payload as JSON. Resolves ONLY when the service confirms
     delivery: FormSubmit answers {"success":"true"}; before a form is
     activated it answers {"success":"false", "message": "...Activation..."}
     with a normal 200 status, so the status code alone is not enough. */
  function send(endpoint, payload) {
    if (!endpoint) return Promise.reject(new Error('not-configured'));
    return fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
      body: JSON.stringify(payload)
    }).then(function (res) {
      if (!res.ok) throw new Error('http-' + res.status);
      return res.json().catch(function () { return {}; });
    }).then(function (data) {
      if (data && 'success' in data && String(data.success) !== 'true') {
        var msg = String(data.message || '');
        if (window.console) console.warn('Form service:', msg);
        throw new Error(/activat/i.test(msg) ? 'needs-activation' : 'rejected');
      }
      if (data && 'ok' in data && !data.ok) throw new Error('rejected');
      return data;
    });
  }
  var NEEDS_ACTIVATION = 'This form is waiting to be activated, so nothing was delivered. Check the inbox it sends to for FormSubmit’s “Activate Form” email.';
  var NOT_CONNECTED = 'This form isn’t connected yet, so nothing was sent. Your message is still here.';
  var SEND_FAILED = 'We couldn’t send your message right now. Please try again.';

  /* =========================================================
     PRIMARY CONTACT FORM
     ========================================================= */
  var form = $('#contact');
  if (form) {
    var fName = $('#c-name'), fEmail = $('#c-email'), fPhone = $('#c-phone'),
        fReason = $('#c-reason'), fMsg = $('#c-message');
    var submitBtn = $('#contact-submit');
    var alertBox = $('#contact-alert');
    var sending = false;

    wireCounter(fMsg);

    /* Preselect the reason from ?reason=host-a-station etc. */
    var preset = params.get('reason');
    if (preset && REASONS[preset]) fReason.value = preset;
    function syncSelect() { fReason.classList.toggle('is-placeholder', !fReason.value); }
    fReason.addEventListener('change', syncSelect);
    syncSelect();
    if (preset && REASONS[preset] && !params.get('preview')) {
      // Arriving from a menu link: bring the form into view.
      window.requestAnimationFrame(function () {
        document.getElementById('contact-form').scrollIntoView({ block: 'start' });
      });
    }

    function checkField(input) {
      var v = input.value.trim();
      if (input === fName) return v ? '' : 'Please enter your full name.';
      if (input === fEmail) {
        if (!v) return 'Please enter your email address.';
        return EMAIL_RE.test(v) ? '' : 'Please enter a valid email address, like you@example.com.';
      }
      if (input === fPhone) return (!v || validPhone(v)) ? '' : 'Please enter a valid phone number, or leave this blank.';
      if (input === fReason) return input.value ? '' : 'Please choose a reason for contacting us.';
      if (input === fMsg) {
        if (!v) return 'Please tell us how we can help.';
        return input.value.length > 500 ? 'Please keep your message to 500 characters.' : '';
      }
      return '';
    }
    var fields = [fName, fEmail, fPhone, fReason, fMsg];

    /* Validate a field once the visitor leaves it; clear errors as they fix them. */
    fields.forEach(function (input) {
      input.addEventListener('blur', function () {
        if (input.value.trim() || input.hasAttribute('aria-invalid')) setError(input, checkField(input));
      });
      input.addEventListener(input.tagName === 'SELECT' ? 'change' : 'input', function () {
        if (input.hasAttribute('aria-invalid')) setError(input, checkField(input));
      });
    });

    form.addEventListener('submit', function (e) {
      e.preventDefault();
      if (sending) return;
      hideAlert(alertBox);

      var firstBad = null;
      fields.forEach(function (input) {
        var msg = checkField(input);
        setError(input, msg);
        if (msg && !firstBad) firstBad = input;
      });
      if (firstBad) { firstBad.focus(); return; }

      sending = true;
      setLoading(submitBtn, true, 'Send Message', 'Sending…');

      var payload = {
        form: 'contact',
        name: fName.value.trim(),
        email: fEmail.value.trim(),
        phone: fPhone.value.trim(),
        reason: REASONS[fReason.value],
        message: fMsg.value.trim(),
        _subject: 'Power Moves — ' + REASONS[fReason.value],
        _replyto: fEmail.value.trim(),
        _template: 'table',
        _honey: form.elements._honey.value
      };

      send(CONTACT_ENDPOINT, payload).then(function () {
        $('#contact-form-wrap').hidden = true;
        var ok = $('#contact-success');
        ok.hidden = false;
        ok.focus();
        form.reset();
      }).catch(function (err) {
        showAlert(alertBox, err.message === 'not-configured' ? NOT_CONNECTED : err.message === 'needs-activation' ? NEEDS_ACTIVATION : SEND_FAILED);
        alertBox.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      }).then(function () {
        sending = false;
        setLoading(submitBtn, false, 'Send Message', 'Sending…');
      });
    });
  }

  /* =========================================================
     PRAYER REQUEST DIALOG
     ========================================================= */
  var dialog = $('#prayer-dialog');
  var prayer = null; // handles used by the design-preview block below
  if (dialog) {
    var openBtn = $('#prayer-open');
    var closeBtn = $('#prayer-close');
    var doneBtn = $('#prayer-done');
    var pForm = $('#prayer-form');
    var pReq = $('#p-request'), pFollow = $('#p-followup'), pFields = $('#p-contact-fields'),
        pEmail = $('#p-email'), pPhone = $('#p-phone');
    var pContactErr = $('#p-contact-error');
    var pSubmit = $('#prayer-submit');
    var pAlert = $('#prayer-alert');
    var pSending = false;

    wireCounter(pReq);

    function openDialog() {
      if (typeof dialog.showModal === 'function') dialog.showModal();
      else dialog.setAttribute('open', '');
      document.body.classList.add('menu-open');
      window.setTimeout(function () {
        var target = $('#prayer-success').hidden ? $('#p-name') : $('#prayer-success');
        if (target) target.focus();
      }, 50);
    }
    function closeDialog() {
      if (typeof dialog.close === 'function' && dialog.open) dialog.close();
      else dialog.removeAttribute('open');
    }
    dialog.addEventListener('close', function () {
      document.body.classList.remove('menu-open');
      // After a successful request, reset so the next visitor starts fresh.
      if (!$('#prayer-success').hidden) {
        pForm.reset();
        toggleFollowup();
        pReq.dispatchEvent(new Event('input'));
        $('#prayer-success').hidden = true;
        $('#prayer-form-wrap').hidden = false;
      }
      if (openBtn) openBtn.focus();
    });
    if (openBtn) openBtn.addEventListener('click', openDialog);
    closeBtn.addEventListener('click', closeDialog);
    doneBtn.addEventListener('click', closeDialog);
    // Click on the dimmed backdrop closes the dialog.
    dialog.addEventListener('click', function (e) { if (e.target === dialog) closeDialog(); });

    function toggleFollowup() {
      var on = pFollow.checked;
      pFields.hidden = !on;
      pFollow.setAttribute('aria-expanded', on ? 'true' : 'false');
      if (!on) {
        [pEmail, pPhone].forEach(function (i) { setError(i, ''); });
        pContactErr.hidden = true;
      }
    }
    pFollow.addEventListener('change', function () {
      toggleFollowup();
      if (pFollow.checked) pEmail.focus();
    });
    toggleFollowup();

    function checkPrayer() {
      var bad = null;
      var req = pReq.value.trim();
      var reqMsg = !req ? 'Please share your prayer request.' : (pReq.value.length > 1000 ? 'Please keep your request to 1,000 characters.' : '');
      setError(pReq, reqMsg);
      if (reqMsg) bad = pReq;

      pContactErr.hidden = true;
      if (pFollow.checked) {
        var e = pEmail.value.trim(), p = pPhone.value.trim();
        var eMsg = e && !EMAIL_RE.test(e) ? 'Please enter a valid email address.' : '';
        var pMsg = p && !validPhone(p) ? 'Please enter a valid phone number.' : '';
        setError(pEmail, eMsg);
        setError(pPhone, pMsg);
        if (eMsg && !bad) bad = pEmail;
        if (pMsg && !bad) bad = pPhone;
        if (!e && !p) {
          pContactErr.querySelector('span').textContent = 'So we can reach you, please add an email address or phone number.';
          pContactErr.hidden = false;
          if (!bad) bad = pEmail;
        }
      }
      return bad;
    }
    [pReq, pEmail, pPhone].forEach(function (input) {
      input.addEventListener('input', function () {
        if (input.hasAttribute('aria-invalid') || !pContactErr.hidden) checkPrayer();
      });
    });

    pForm.addEventListener('submit', function (e) {
      e.preventDefault();
      if (pSending) return;
      hideAlert(pAlert);
      var bad = checkPrayer();
      if (bad) { bad.focus(); return; }

      pSending = true;
      setLoading(pSubmit, true, 'Submit Prayer Request', 'Submitting…');

      var wantsFollowup = pFollow.checked;
      // Contact details are only included when follow-up was requested.
      var payload = {
        form: 'prayer-request',
        name: $('#p-name').value.trim(),
        request: pReq.value.trim(),
        follow_up_requested: wantsFollowup ? 'Yes' : 'No',
        email: wantsFollowup ? pEmail.value.trim() : '',
        phone: wantsFollowup ? pPhone.value.trim() : '',
        _subject: 'Power Moves — Prayer request',
        _template: 'table',
        _honey: pForm.elements._honey.value
      };
      // Lets you hit Reply in your inbox when they asked for follow-up by email.
      if (wantsFollowup && payload.email) payload._replyto = payload.email;

      send(PRAYER_ENDPOINT, payload).then(function () {
        $('#prayer-success-followup').hidden = !wantsFollowup;
        $('#prayer-form-wrap').hidden = true;
        var ok = $('#prayer-success');
        ok.hidden = false;
        ok.focus();
      }).catch(function (err) {
        showAlert(pAlert, err.message === 'not-configured'
          ? 'This form isn’t connected yet, so nothing was sent. What you wrote is still here.'
          : err.message === 'needs-activation' ? NEEDS_ACTIVATION
          : 'We couldn’t send your prayer request right now. Please try again.');
      }).then(function () {
        pSending = false;
        setLoading(pSubmit, false, 'Submit Prayer Request', 'Submitting…');
      });
    });

    prayer = { open: openDialog, toggleFollowup: toggleFollowup, followup: pFollow };

    // contact.html#share-prayer opens the form directly.
    if (window.location.hash === '#share-prayer') openDialog();
  }

  /* =========================================================
     DESIGN PREVIEW STATES (for reviewing the design only)
     contact.html?preview=sent         → contact confirmation
     contact.html?preview=errors       → validation errors
     contact.html?preview=prayer       → prayer form open
     contact.html?preview=prayer-sent  → prayer confirmation (with follow-up line)
     These are clearly labelled and never sent anywhere.
     ========================================================= */
  var preview = params.get('preview');
  if (preview) {
    var badge = function (root) {
      var b = document.createElement('span');
      b.className = 'preview-badge';
      b.textContent = 'DESIGN PREVIEW';
      root.appendChild(b);
    };
    if (preview === 'sent') {
      $('#contact-form-wrap').hidden = true;
      $('#contact-success').hidden = false;
      badge($('.ct-card'));
    } else if (preview === 'errors' && form) {
      form.dispatchEvent(new Event('submit', { cancelable: true }));
      badge($('.ct-card'));
    } else if ((preview === 'prayer' || preview === 'prayer-sent') && prayer) {
      if (preview === 'prayer-sent') {
        $('#prayer-form-wrap').hidden = true;
        $('#prayer-success').hidden = false;
        $('#prayer-success-followup').hidden = false;
      } else {
        prayer.followup.checked = true;
        prayer.toggleFollowup();
      }
      badge($('.pd-inner'));
      prayer.open();
    }
  }
})();
